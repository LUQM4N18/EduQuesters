import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface QuizInterfaceProps {
  quiz: any;
  onComplete: (score: number, total: number) => void;
  onBack: () => void;
}

export default function QuizInterface({ quiz, onComplete, onBack }: QuizInterfaceProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);

  const questions = quiz.questions || [];
  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer === null) return;

    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);

    if (selectedAnswer === question.correctAnswer) {
      setScore(score + 1);
    }

    if (currentQuestion + 1 < questions.length) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      // Quiz complete
      const finalScore = selectedAnswer === question.correctAnswer ? score + 1 : score;
      onComplete(finalScore, questions.length);
    }
  };

  if (!question) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">No questions available for this quiz.</div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Card className="card-shadow">
        <CardContent className="p-8">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-foreground" data-testid="quiz-title">
                {quiz.title}
              </h2>
              <span className="bg-secondary px-3 py-1 rounded-full text-sm font-medium">
                Question <span data-testid="current-question">{currentQuestion + 1}</span> of {questions.length}
              </span>
            </div>
            <div className="w-full bg-secondary rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full progress-bar" 
                style={{width: `${progress}%`}}
                data-testid="quiz-progress"
              />
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-semibold text-foreground mb-6" data-testid="question-text">
              {question.question}
            </h3>
            
            <div className="space-y-3">
              {question.options?.map((option: string, index: number) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  data-testid={`quiz-option-${index}`}
                  className={`w-full text-left p-4 border rounded-lg transition-colors ${
                    selectedAnswer === index
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary hover:bg-primary/5"
                  }`}
                >
                  <span className="font-medium text-muted-foreground mr-3">
                    {String.fromCharCode(65 + index)})
                  </span>
                  <span>{option}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <Button 
              variant="ghost"
              onClick={onBack}
              data-testid="button-back-to-quizzes"
            >
              ← Back to Quizzes
            </Button>
            <Button
              onClick={handleNextQuestion}
              disabled={selectedAnswer === null}
              data-testid="button-next-question"
            >
              {currentQuestion + 1 === questions.length ? "Finish Quiz" : "Next Question"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
