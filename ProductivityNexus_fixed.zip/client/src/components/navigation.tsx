import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function Navigation() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { path: "/home", label: "Home" },
    { path: "/dashboard", label: "Dashboard" },
    { path: "/lessons", label: "Lessons" },
    { path: "/quizzes", label: "Quizzes" },
    { path: "/puzzles", label: "Puzzles" },
    { path: "/challenges", label: "Challenges" },
    { path: "/leaderboard", label: "Leaderboard" },
    { path: "/profile", label: "Profile" },
  ];

  return (
    <nav className="bg-white shadow-sm border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center mr-3">
                <span className="text-primary-foreground font-bold text-lg">🌱</span>
              </div>
              <span className="text-xl font-bold text-foreground">EcoQuest</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <button
                  data-testid={`nav-${item.label.toLowerCase()}`}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    location === item.path
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                  }`}
                >
                  {item.label}
                </button>
              </Link>
            ))}
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center bg-accent/10 px-3 py-1 rounded-full">
              <span className="text-accent mr-2">🏆</span>
              <span className="text-sm font-semibold text-accent" data-testid="user-points">
                {user?.ecoPoints || 0}
              </span>
              <span className="text-xs text-muted-foreground ml-1">points</span>
            </div>
            <button
              onClick={() => logout()}
              data-testid="button-logout"
              className="text-sm text-muted-foreground hover:text-foreground"
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
