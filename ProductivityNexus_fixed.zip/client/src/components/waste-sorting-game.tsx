import { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface WasteSortingGameProps {
  puzzle: any;
}

export default function WasteSortingGame({ puzzle }: WasteSortingGameProps) {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes
  const [gameItems, setGameItems] = useState(puzzle.config?.items || []);
  const [draggedItem, setDraggedItem] = useState<any>(null);
  const { toast } = useToast();
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const bins = puzzle.config?.bins || [];

  const handleDragStart = (e: React.DragEvent, item: any) => {
    setDraggedItem(item);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, binType: string) => {
    e.preventDefault();
    
    if (!draggedItem) return;

    const isCorrect = draggedItem.type === binType;
    
    if (isCorrect) {
      setScore(score + 10);
      setGameItems(gameItems.filter((item: any) => item !== draggedItem));
      toast({
        title: "Correct!",
        description: `+10 points for sorting ${draggedItem.name} correctly!`,
      });
    } else {
      toast({
        title: "Oops!",
        description: `${draggedItem.name} doesn't go in the ${binType} bin. Try again!`,
        variant: "destructive",
      });
    }

    setDraggedItem(null);
  };

  const resetGame = () => {
    setScore(0);
    setTimeLeft(120);
    setGameItems(puzzle.config?.items || []);
    setDraggedItem(null);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  const showHint = () => {
    toast({
      title: "Hint!",
      description: "Organic waste goes in the green bin, plastic in blue, paper in yellow, and non-recyclable items in gray!",
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getBinColor = (type: string) => {
    const colors: Record<string, string> = {
      plastic: "border-blue-300 bg-blue-100 hover:border-blue-500",
      organic: "border-green-300 bg-green-100 hover:border-green-500",
      paper: "border-yellow-300 bg-yellow-100 hover:border-yellow-500",
      general: "border-gray-300 bg-gray-100 hover:border-gray-500"
    };
    return colors[type] || "border-gray-300 bg-gray-100";
  };

  const getBinTextColor = (type: string) => {
    const colors: Record<string, string> = {
      plastic: "text-blue-700",
      organic: "text-green-700", 
      paper: "text-yellow-700",
      general: "text-gray-700"
    };
    return colors[type] || "text-gray-700";
  };

  return (
    <Card className="card-shadow mb-8">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-2">Waste Sorting Challenge</h2>
          <p className="text-muted-foreground">Drag and drop items into the correct recycling bins</p>
          <div className="mt-4 flex items-center justify-center space-x-6">
            <div className="text-center">
              <span className="text-accent text-2xl font-bold" data-testid="puzzle-score">
                {score}
              </span>
              <div className="text-xs text-muted-foreground">Score</div>
            </div>
            <div className="text-center">
              <span className="text-primary text-2xl font-bold" data-testid="puzzle-timer">
                {formatTime(timeLeft)}
              </span>
              <div className="text-xs text-muted-foreground">Time Left</div>
            </div>
          </div>
        </div>

        {/* Recycling Bins */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {bins.map((bin: any) => (
            <div
              key={bin.type}
              className={`border-2 border-dashed rounded-xl p-6 text-center min-h-32 transition-colors ${getBinColor(bin.type)}`}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, bin.type)}
              data-testid={`bin-${bin.type}`}
            >
              <div className="text-4xl mb-2">{bin.emoji}</div>
              <h3 className={`font-semibold ${getBinTextColor(bin.type)}`}>{bin.name}</h3>
              <p className={`text-xs mt-1 ${getBinTextColor(bin.type).replace('700', '600')}`}>
                {bin.type === 'plastic' && 'Bottles, containers'}
                {bin.type === 'organic' && 'Food scraps, compost'}
                {bin.type === 'paper' && 'Newspapers, cardboard'}
                {bin.type === 'general' && 'Non-recyclable waste'}
              </p>
            </div>
          ))}
        </div>

        {/* Draggable Items */}
        <div className="bg-secondary rounded-xl p-6">
          <h3 className="font-semibold text-foreground mb-4">Items to Sort:</h3>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            {gameItems.map((item: any, index: number) => (
              <div
                key={index}
                draggable
                onDragStart={(e) => handleDragStart(e, item)}
                className="bg-white rounded-lg p-4 text-center cursor-move hover:shadow-md transition-shadow border border-border"
                data-testid={`waste-item-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="text-2xl mb-1">{item.emoji}</div>
                <div className="text-xs font-medium">{item.name}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 text-center space-x-4">
          <Button 
            onClick={resetGame}
            variant="secondary"
            data-testid="button-reset-game"
          >
            Reset Game
          </Button>
          <Button
            onClick={showHint}
            data-testid="button-show-hint"
          >
            💡 Show Hint
          </Button>
        </div>

        {gameItems.length === 0 && (
          <div className="text-center mt-6 p-4 bg-primary/10 rounded-lg">
            <h3 className="font-bold text-primary text-lg">Congratulations! 🎉</h3>
            <p className="text-muted-foreground">
              You've sorted all items correctly! Final score: {score} points
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
