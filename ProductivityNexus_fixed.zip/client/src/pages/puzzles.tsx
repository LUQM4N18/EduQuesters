import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import WasteSortingGame from "@/components/waste-sorting-game";

export default function Puzzles() {
  const { data: puzzles, isLoading } = useQuery({
    queryKey: ["/api/puzzles"],
  });

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">Loading puzzles...</div>
      </div>
    );
  }

  const wasteSortingPuzzle = (puzzles as any[])?.find((p: any) => p.type === 'waste-sorting');
  
  const otherGames = [
    {
      title: "Water Cycle Puzzle",
      description: "Arrange the water cycle stages in correct order",
      emoji: "💧",
      color: "blue"
    },
    {
      title: "Ecosystem Matching",
      description: "Match animals with their natural habitats",
      emoji: "🌳",
      color: "green"
    },
    {
      title: "Energy Efficiency",
      description: "Find energy-saving solutions in a virtual home",
      emoji: "⚡",
      color: "yellow"
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Eco Puzzles</h1>
        <p className="text-muted-foreground mt-2">Learn through fun interactive games and puzzles</p>
      </div>

      {/* Waste Sorting Game */}
      {wasteSortingPuzzle && <WasteSortingGame puzzle={wasteSortingPuzzle} />}

      {/* Other Puzzle Games */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {otherGames.map((game, index) => (
          <Card key={index} className="card-shadow hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className={`w-16 h-16 bg-${game.color}-100 rounded-xl flex items-center justify-center mx-auto mb-4`}>
                <span className="text-2xl">{game.emoji}</span>
              </div>
              <h3 className="font-semibold text-foreground mb-2" data-testid={`game-${game.title.toLowerCase().replace(/\s+/g, '-')}`}>
                {game.title}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">{game.description}</p>
              <button 
                className="text-primary hover:text-primary/80 text-sm font-medium"
                data-testid={`button-play-${game.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                Play Now →
              </button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
