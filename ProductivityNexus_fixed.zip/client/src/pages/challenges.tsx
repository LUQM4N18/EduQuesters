import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Challenges() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: challenges, isLoading } = useQuery({
    queryKey: ["/api/challenges"],
  });

  const { data: userProgress } = useQuery({
    queryKey: ["/api/users", user?.id, "progress"],
    enabled: !!user?.id,
  });

  const { data: userBadges } = useQuery({
    queryKey: ["/api/users", user?.id, "badges"],
    enabled: !!user?.id,
  });

  const completChallengeMutation = useMutation({
    mutationFn: async (challengeId: string) => {
      const response = await fetch(`/api/users/${user?.id}/progress`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          challengeId,
          completed: true,
          score: 100,
        }),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.id, "progress"] });
      toast({
        title: "Challenge Completed!",
        description: "Great job! You've earned eco-points and progress towards your next badge.",
      });
    },
  });

  const updatePointsMutation = useMutation({
    mutationFn: async ({ points }: { points: number }) => {
      const response = await fetch(`/api/users/${user?.id}/points`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ points }),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    },
  });

  const awardBadgeMutation = useMutation({
    mutationFn: async (badgeId: string) => {
      const response = await fetch(`/api/users/${user?.id}/badges`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ badgeId }),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.id, "badges"] });
    },
  });

  const handleCompleteChallenge = async (challenge: any) => {
    try {
      await completChallengeMutation.mutateAsync(challenge.id);
      await updatePointsMutation.mutateAsync({ points: challenge.points });
      
      // Award badge if specified and not already earned
      if (challenge.badgeId) {
        const hasBadge = (userBadges as any[])?.some((ub: any) => ub.badgeId === challenge.badgeId);
        if (!hasBadge) {
          await awardBadgeMutation.mutateAsync(challenge.badgeId);
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete challenge. Please try again.",
        variant: "destructive",
      });
    }
  };

  const isCompleted = (challengeId: string) => {
    return (userProgress as any[])?.some((p: any) => p.challengeId === challengeId && p.completed);
  };

  const getCompletedChallenges = () => {
    return (userProgress as any[])?.filter((p: any) => p.challengeId && p.completed).length || 0;
  };

  const getActiveChallenges = () => {
    return (challenges as any[])?.filter((c: any) => c.isActive && !isCompleted(c.id)).length || 0;
  };

  const getStreak = () => {
    // Simple streak calculation - could be enhanced with actual date tracking
    return Math.min(getCompletedChallenges(), 7);
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">Loading challenges...</div>
      </div>
    );
  }

  const dailyChallenges = (challenges as any[])?.filter((c: any) => c.type === 'daily') || [];
  const weeklyChallenges = (challenges as any[])?.filter((c: any) => c.type === 'weekly') || [];
  const monthlyChallenges = (challenges as any[])?.filter((c: any) => c.type === 'monthly') || [];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Eco Challenges</h1>
        <p className="text-muted-foreground mt-2">Complete real-world environmental tasks and earn rewards</p>
      </div>

      {/* Challenge Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="card-shadow">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-primary" data-testid="challenges-completed">
              {getCompletedChallenges()}
            </div>
            <div className="text-sm text-muted-foreground">Completed</div>
          </CardContent>
        </Card>
        <Card className="card-shadow">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-accent" data-testid="challenges-active">
              {getActiveChallenges()}
            </div>
            <div className="text-sm text-muted-foreground">Active</div>
          </CardContent>
        </Card>
        <Card className="card-shadow">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-blue-600" data-testid="challenges-streak">
              {getStreak()}
            </div>
            <div className="text-sm text-muted-foreground">Day Streak</div>
          </CardContent>
        </Card>
      </div>

      {/* Daily Challenges */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-foreground mb-4">Today's Challenges</h2>
        <div className="space-y-4">
          {dailyChallenges.map((challenge: any) => (
            <Card key={challenge.id} className="card-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <span className="text-xl">{challenge.emoji}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground" data-testid={`challenge-title-${challenge.id}`}>
                        {challenge.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">{challenge.description}</p>
                      <div className="flex items-center mt-2">
                        <span className="text-accent text-sm mr-2">🏆 {challenge.points} points</span>
                        {challenge.badgeId && (
                          <span className="text-primary text-sm">🥇 Badge reward</span>
                        )}
                      </div>
                    </div>
                  </div>
                  {isCompleted(challenge.id) ? (
                    <div className="bg-green-100 text-green-700 px-4 py-2 rounded-lg text-sm font-medium">
                      Completed
                    </div>
                  ) : (
                    <Button
                      onClick={() => handleCompleteChallenge(challenge)}
                      disabled={completChallengeMutation.isPending}
                      data-testid={`button-complete-${challenge.id}`}
                    >
                      {completChallengeMutation.isPending ? "Completing..." : "Mark Complete"}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Weekly Challenges */}
      {weeklyChallenges.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-foreground mb-4">Weekly Challenges</h2>
          <div className="space-y-4">
            {weeklyChallenges.map((challenge: any) => (
              <Card key={challenge.id} className="card-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                        <span className="text-xl">{challenge.emoji}</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground" data-testid={`weekly-challenge-${challenge.id}`}>
                          {challenge.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">{challenge.description}</p>
                        <div className="flex items-center mt-2">
                          <span className="text-accent text-sm mr-2">🏆 {challenge.points} points</span>
                          {challenge.badgeId && (
                            <span className="text-green-600 text-sm">🌳 {challenge.badgeId} badge</span>
                          )}
                        </div>
                      </div>
                    </div>
                    {isCompleted(challenge.id) ? (
                      <div className="bg-green-100 text-green-700 px-4 py-2 rounded-lg text-sm font-medium">
                        Completed
                      </div>
                    ) : (
                      <Button
                        onClick={() => handleCompleteChallenge(challenge)}
                        disabled={completChallengeMutation.isPending}
                        data-testid={`button-accept-${challenge.id}`}
                      >
                        Accept Challenge
                      </Button>
                    )}
                  </div>
                  {!isCompleted(challenge.id) && (
                    <>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-orange-500 h-2 rounded-full progress-bar" style={{width: "60%"}}></div>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground mt-1">
                        <span>Progress: 3/5 days</span>
                        <span>2 days left</span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Monthly Challenges */}
      {monthlyChallenges.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold text-foreground mb-4">Monthly Challenge</h2>
          {monthlyChallenges.map((challenge: any) => (
            <div key={challenge.id} className="bg-gradient-to-r from-primary/20 to-accent/20 rounded-xl p-6">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center">
                  <span className="text-2xl">{challenge.emoji}</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground" data-testid={`monthly-challenge-${challenge.id}`}>
                    {challenge.title}
                  </h3>
                  <p className="text-muted-foreground">{challenge.description}</p>
                  <div className="flex items-center mt-2">
                    <span className="text-accent text-lg font-semibold mr-4">🏆 {challenge.points} points</span>
                    {challenge.badgeId && (
                      <span className="text-yellow-600 text-lg font-semibold">🥇 Champion badge</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="w-full bg-white/30 rounded-full h-3 mb-2">
                <div className="bg-primary h-3 rounded-full progress-bar" style={{width: "35%"}}></div>
              </div>
              <div className="flex justify-between text-sm text-foreground/80">
                <span>Progress: 11/31 days</span>
                <span>20 days remaining</span>
              </div>
              <div className="mt-4">
                {isCompleted(challenge.id) ? (
                  <div className="bg-white/20 text-foreground px-6 py-2 rounded-lg font-medium">
                    Completed! 🎉
                  </div>
                ) : (
                  <Button
                    onClick={() => handleCompleteChallenge(challenge)}
                    disabled={completChallengeMutation.isPending}
                    className="bg-white text-foreground hover:bg-white/90"
                    data-testid={`button-monthly-${challenge.id}`}
                  >
                    View Details
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
