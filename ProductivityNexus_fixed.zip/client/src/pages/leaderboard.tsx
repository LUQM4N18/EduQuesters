import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type FilterType = 'global' | 'school' | 'class' | 'friends';
type PeriodType = 'week' | 'month' | 'all';

export default function Leaderboard() {
  const { user } = useAuth();
  const [filter, setFilter] = useState<FilterType>('global');
  const [period, setPeriod] = useState<PeriodType>('week');

  const { data: users, isLoading } = useQuery({
    queryKey: ["/api/users"],
  });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">Loading leaderboard...</div>
      </div>
    );
  }

  // Filter users based on current user's school if needed
  const filteredUsers = (users as any[])?.filter((u: any) => {
    if (filter === 'school' && user?.school) {
      return u.school === user.school;
    }
    return true;
  }) || [];

  // Sort by eco points
  const sortedUsers = [...filteredUsers].sort((a: any, b: any) => (b.ecoPoints || 0) - (a.ecoPoints || 0));

  // Find current user's rank
  const currentUserRank = sortedUsers.findIndex((u: any) => u.id === user?.id) + 1;
  const currentUser = sortedUsers.find((u: any) => u.id === user?.id);

  // Get top 3 for podium
  const topThree = sortedUsers.slice(0, 3);
  const remainingUsers = sortedUsers.slice(3);

  const filterButtons: { key: FilterType; label: string }[] = [
    { key: 'global', label: 'Global' },
    { key: 'school', label: 'School' },
    { key: 'class', label: 'Class' },
    { key: 'friends', label: 'Friends' },
  ];

  const periodButtons: { key: PeriodType; label: string }[] = [
    { key: 'week', label: 'This Week' },
    { key: 'month', label: 'This Month' },
    { key: 'all', label: 'All Time' },
  ];

  const getRankEmoji = (rank: number) => {
    switch (rank) {
      case 1: return "👨";
      case 2: return "👩";
      case 3: return "👦";
      default: return "👤";
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return "bg-yellow-200";
      case 2: return "bg-gray-200";
      case 3: return "bg-orange-200";
      default: return "bg-blue-200";
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1: return "bg-yellow-500";
      case 2: return "bg-gray-400";
      case 3: return "bg-orange-500";
      default: return "bg-muted";
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Leaderboard</h1>
        <p className="text-muted-foreground mt-2">See how you rank against other eco warriors</p>
      </div>

      {/* Ranking Filters */}
      <Card className="card-shadow mb-8">
        <CardContent className="p-6">
          <div className="flex flex-wrap gap-4 mb-6">
            {filterButtons.map((btn) => (
              <Button
                key={btn.key}
                onClick={() => setFilter(btn.key)}
                variant={filter === btn.key ? "default" : "secondary"}
                size="sm"
                data-testid={`filter-${btn.key}`}
              >
                {btn.label}
              </Button>
            ))}
          </div>
          
          <div className="flex flex-wrap gap-4">
            {periodButtons.map((btn) => (
              <Button
                key={btn.key}
                onClick={() => setPeriod(btn.key)}
                variant={period === btn.key ? "outline" : "ghost"}
                size="sm"
                className={period === btn.key ? "bg-accent/20 text-accent border-accent" : ""}
                data-testid={`period-${btn.key}`}
              >
                {btn.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top 3 Podium */}
      {topThree.length >= 3 && (
        <Card className="card-shadow mb-8">
          <CardContent className="p-8">
            <h2 className="text-xl font-semibold text-foreground mb-6 text-center">Top Eco Warriors</h2>
            <div className="flex items-end justify-center space-x-8">
              {/* 2nd Place */}
              <div className="text-center">
                <div className={`w-16 h-16 ${getRankColor(2)} rounded-full flex items-center justify-center mx-auto mb-3 relative`}>
                  <span className="text-2xl">{getRankEmoji(2)}</span>
                  <div className={`absolute -top-2 -right-2 w-8 h-8 ${getRankBadgeColor(2)} rounded-full flex items-center justify-center`}>
                    <span className="text-white text-sm font-bold">2</span>
                  </div>
                </div>
                <div className="font-semibold text-foreground" data-testid="podium-second-name">
                  {topThree[1]?.fullName}
                </div>
                <div className="text-sm text-muted-foreground">{topThree[1]?.school}</div>
                <div className="text-accent font-bold mt-1" data-testid="podium-second-points">
                  {topThree[1]?.ecoPoints || 0} pts
                </div>
              </div>

              {/* 1st Place */}
              <div className="text-center transform scale-110">
                <div className={`w-20 h-20 ${getRankColor(1)} rounded-full flex items-center justify-center mx-auto mb-3 relative`}>
                  <span className="text-3xl">{getRankEmoji(1)}</span>
                  <div className={`absolute -top-3 -right-3 w-10 h-10 ${getRankBadgeColor(1)} rounded-full flex items-center justify-center`}>
                    <span className="text-white font-bold">1</span>
                  </div>
                </div>
                <div className="font-bold text-foreground text-lg" data-testid="podium-first-name">
                  {topThree[0]?.fullName}
                </div>
                <div className="text-sm text-muted-foreground">{topThree[0]?.school}</div>
                <div className="text-accent font-bold text-lg mt-1" data-testid="podium-first-points">
                  {topThree[0]?.ecoPoints || 0} pts
                </div>
                <div className="text-xs text-yellow-600 mt-1">👑 Champion</div>
              </div>

              {/* 3rd Place */}
              <div className="text-center">
                <div className={`w-16 h-16 ${getRankColor(3)} rounded-full flex items-center justify-center mx-auto mb-3 relative`}>
                  <span className="text-2xl">{getRankEmoji(3)}</span>
                  <div className={`absolute -top-2 -right-2 w-8 h-8 ${getRankBadgeColor(3)} rounded-full flex items-center justify-center`}>
                    <span className="text-white text-sm font-bold">3</span>
                  </div>
                </div>
                <div className="font-semibold text-foreground" data-testid="podium-third-name">
                  {topThree[2]?.fullName}
                </div>
                <div className="text-sm text-muted-foreground">{topThree[2]?.school}</div>
                <div className="text-accent font-bold mt-1" data-testid="podium-third-points">
                  {topThree[2]?.ecoPoints || 0} pts
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Full Leaderboard */}
      <Card className="card-shadow">
        <div className="p-6 border-b border-border">
          <h2 className="text-xl font-semibold text-foreground">All Rankings</h2>
        </div>
        
        <div className="divide-y divide-border">
          {/* Current User Position (if not in top 3) */}
          {currentUser && currentUserRank > 3 && (
            <div className="p-6 bg-primary/5">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-primary-foreground font-bold text-sm" data-testid="user-rank">
                      {currentUserRank}
                    </span>
                  </div>
                  <div className="w-12 h-12 bg-blue-200 rounded-full flex items-center justify-center">
                    <span className="text-xl">👤</span>
                  </div>
                  <div>
                    <div className="font-semibold text-foreground" data-testid="user-name">
                      You ({currentUser.fullName})
                    </div>
                    <div className="text-sm text-muted-foreground">{currentUser.school}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-accent font-bold" data-testid="user-points">
                    {currentUser.ecoPoints || 0} pts
                  </div>
                  <div className="text-xs text-muted-foreground">+45 this week</div>
                </div>
              </div>
            </div>
          )}

          {/* Other users */}
          {remainingUsers.map((user: any, index: number) => {
            const rank = index + 4; // Starting from 4th place
            return (
              <div 
                key={user.id} 
                className="p-6 hover:bg-secondary/50 transition-colors"
                data-testid={`leaderboard-user-${rank}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                      <span className="text-muted-foreground font-medium text-sm">{rank}</span>
                    </div>
                    <div className={`w-12 h-12 ${getRankColor(rank)} rounded-full flex items-center justify-center`}>
                      <span className="text-xl">{getRankEmoji(rank)}</span>
                    </div>
                    <div>
                      <div className="font-medium text-foreground">{user.fullName}</div>
                      <div className="text-sm text-muted-foreground">{user.school}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-accent font-semibold">{user.ecoPoints || 0} pts</div>
                    <div className="text-xs text-muted-foreground">+{Math.floor(Math.random() * 50 + 10)} this week</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="p-6 text-center border-t border-border">
          <button className="text-primary hover:text-primary/80 text-sm font-medium" data-testid="button-view-more">
            View More Rankings →
          </button>
        </div>
      </Card>
    </div>
  );
}
