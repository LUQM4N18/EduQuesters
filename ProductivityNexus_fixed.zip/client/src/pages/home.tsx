import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  const { user } = useAuth();

  const { data: randomTip } = useQuery({
    queryKey: ["/api/eco-tips/random"],
  });

  const navigationItems = [
    { path: "/lessons", label: "Lessons", description: "Learn eco concepts", emoji: "📚", color: "blue" },
    { path: "/quizzes", label: "Quizzes", description: "Test your knowledge", emoji: "🧠", color: "purple" },
    { path: "/puzzles", label: "Puzzles", description: "Fun eco games", emoji: "🧩", color: "green" },
    { path: "/challenges", label: "Challenges", description: "Real-world tasks", emoji: "🎯", color: "orange" },
    { path: "/dashboard", label: "Dashboard", description: "Track progress", emoji: "📊", color: "indigo" },
    { path: "/leaderboard", label: "Leaderboard", description: "See rankings", emoji: "🏅", color: "yellow" },
    { path: "/profile", label: "Profile", description: "Your achievements", emoji: "👤", color: "pink" },
  ];

  const getColorClasses = (color: string) => {
    const colorMap: Record<string, string> = {
      blue: "bg-blue-100",
      purple: "bg-purple-100", 
      green: "bg-green-100",
      orange: "bg-orange-100",
      indigo: "bg-indigo-100",
      yellow: "bg-yellow-100",
      pink: "bg-pink-100"
    };
    return colorMap[color] || "bg-gray-100";
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Header */}
      <div className="gradient-bg rounded-2xl p-8 mb-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2" data-testid="text-welcome">
              Welcome back, {user?.fullName}! 👋
            </h1>
            <p className="text-white/90 text-lg">Ready to continue your eco journey?</p>
          </div>
          <div className="hidden md:block">
            <div className="text-right">
              <div className="text-2xl font-bold" data-testid="text-user-level">
                Level {user?.level || 1}
              </div>
              <div className="text-white/80">Eco Warrior</div>
            </div>
          </div>
        </div>
      </div>

      {/* Daily Eco Tip */}
      {randomTip && (
        <Card className="card-shadow mb-8">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-12 h-12 bg-accent/20 rounded-xl flex items-center justify-center">
                <span className="text-2xl">{(randomTip as any)?.emoji || "💡"}</span>
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg text-foreground mb-2">Daily Eco Tip</h3>
                <p className="text-muted-foreground" data-testid="text-daily-tip">
                  {(randomTip as any)?.content || "Loading eco tip..."}
                </p>
                <div className="mt-4">
                  <button
                    data-testid="button-share-tip"
                    className="text-primary hover:text-primary/80 text-sm font-medium"
                  >
                    Share this tip →
                  </button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="card-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Eco Points</p>
                <p className="text-2xl font-bold text-accent" data-testid="text-eco-points">
                  {user?.ecoPoints || 0}
                </p>
              </div>
              <div className="w-12 h-12 bg-accent/20 rounded-xl flex items-center justify-center">
                <span className="text-xl">🏆</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="card-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Current Level</p>
                <p className="text-2xl font-bold text-primary" data-testid="text-current-level">
                  {user?.level || 1}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
                <span className="text-xl">🥇</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="card-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">School</p>
                <p className="text-lg font-bold text-blue-600" data-testid="text-user-school">
                  {user?.school}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <span className="text-xl">🏫</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Navigation Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {navigationItems.slice(0, 7).map((item) => (
          <Link key={item.path} href={item.path}>
            <Card className="card-shadow hover:shadow-lg transition-shadow group cursor-pointer">
              <CardContent className="p-6 text-center">
                <div className={`w-16 h-16 ${getColorClasses(item.color)} rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-105 transition-transform`}>
                  <span className="text-2xl">{item.emoji}</span>
                </div>
                <h3 className="font-semibold text-foreground" data-testid={`nav-card-${item.label.toLowerCase()}`}>
                  {item.label}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}

        <div className="bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl p-6 text-center">
          <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">✨</span>
          </div>
          <h3 className="font-semibold text-foreground">Coming Soon</h3>
          <p className="text-sm text-muted-foreground mt-1">New features</p>
        </div>
      </div>
    </div>
  );
}
