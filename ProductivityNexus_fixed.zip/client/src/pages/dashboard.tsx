import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: progress } = useQuery({
    queryKey: ["/api/users", user?.id, "progress"],
    enabled: !!user?.id,
  });

  const { data: badges } = useQuery({
    queryKey: ["/api/users", user?.id, "badges"],
    enabled: !!user?.id,
  });

  // Calculate progress percentages
  const levelProgress = user ? ((user.ecoPoints || 0) % 1000) / 10 : 0;
  const lessonsCompleted = progress ? (progress as any[]).filter((p: any) => p.lessonId && p.completed).length : 0;
  const challengesCompleted = progress ? (progress as any[]).filter((p: any) => p.challengeId && p.completed).length : 0;

  const quickActions = [
    { path: "/quizzes", label: "Take Quiz", description: "Test your eco knowledge", emoji: "🧠", color: "purple" },
    { path: "/challenges", label: "New Challenge", description: "Complete daily tasks", emoji: "🎯", color: "orange" },
    { path: "/lessons", label: "Continue Learning", description: "Next: Renewable Energy", emoji: "📚", color: "blue" },
    { path: "/puzzles", label: "Play Puzzle", description: "Waste sorting game", emoji: "🧩", color: "green" },
  ];

  const recentActivity = [
    { type: "lesson", title: "Completed 'Renewable Energy' lesson", points: 50, time: "2 hours ago", color: "green" },
    { type: "quiz", title: "Scored 90% on Climate Change Quiz", points: 75, time: "Yesterday", color: "blue" },
    { type: "challenge", title: "Completed 'Use Reusable Water Bottle' challenge", points: 30, time: "Yesterday", color: "orange" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2">Track your eco journey and achievements</p>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <Card className="card-shadow">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">Progress Overview</h2>
              
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-foreground">Level Progress</span>
                    <span className="text-sm text-muted-foreground">{levelProgress}% to Level {(user?.level || 1) + 1}</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-3">
                    <div 
                      className="bg-primary h-3 rounded-full progress-bar" 
                      style={{width: `${levelProgress}%`}}
                      data-testid="progress-level"
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-foreground">Lessons Completed</span>
                    <span className="text-sm text-muted-foreground" data-testid="text-lessons-completed">
                      {lessonsCompleted}/15
                    </span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-3">
                    <div 
                      className="bg-blue-500 h-3 rounded-full progress-bar" 
                      style={{width: `${(lessonsCompleted / 15) * 100}%`}}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-foreground">Challenges Completed</span>
                    <span className="text-sm text-muted-foreground" data-testid="text-challenges-completed">
                      {challengesCompleted}/10
                    </span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-3">
                    <div 
                      className="bg-accent h-3 rounded-full progress-bar" 
                      style={{width: `${(challengesCompleted / 10) * 100}%`}}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="card-shadow">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-6">Recent Badges</h2>
            <div className="space-y-4">
              {(badges as any[])?.slice(0, 3).map((userBadge: any, index: number) => (
                <div key={userBadge.id} className="flex items-center space-x-3">
                  <div className={`w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center ${index === 0 ? 'badge-glow' : ''}`}>
                    <span className="text-xl">{userBadge.badge?.emoji}</span>
                  </div>
                  <div>
                    <p className="font-medium text-foreground" data-testid={`badge-${index}`}>
                      {userBadge.badge?.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Earned {new Date(userBadge.earnedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              )) || (
                <p className="text-muted-foreground text-sm">No badges earned yet. Complete challenges to earn your first badge!</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {quickActions.map((action) => (
          <Link key={action.path} href={action.path}>
            <Card className="card-shadow hover:shadow-lg transition-shadow group cursor-pointer">
              <CardContent className="p-6 text-left">
                <div className={`w-12 h-12 bg-${action.color}-100 rounded-lg flex items-center justify-center mb-4 group-hover:scale-105 transition-transform`}>
                  <span className="text-xl">{action.emoji}</span>
                </div>
                <h3 className="font-semibold text-foreground mb-2" data-testid={`action-${action.label.toLowerCase().replace(' ', '-')}`}>
                  {action.label}
                </h3>
                <p className="text-sm text-muted-foreground">{action.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Recent Activity */}
      <Card className="card-shadow">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold text-foreground mb-6">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className={`flex items-center space-x-4 p-4 bg-${activity.color}-50 rounded-lg`}>
                <div className={`w-10 h-10 bg-${activity.color === 'green' ? 'primary' : activity.color === 'blue' ? 'blue-500' : 'accent'} rounded-lg flex items-center justify-center`}>
                  <span className="text-white text-sm">
                    {activity.type === 'lesson' ? '✓' : activity.type === 'quiz' ? '🧠' : '🎯'}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-foreground" data-testid={`activity-${index}`}>
                    {activity.title}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Earned {activity.points} eco-points • {activity.time}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
