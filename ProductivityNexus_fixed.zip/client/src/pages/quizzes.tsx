import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import QuizInterface from "@/components/quiz-interface";

export default function Quizzes() {
  const [selectedQuiz, setSelectedQuiz] = useState<any>(null);
  const [showResults, setShowResults] = useState(false);
  const [quizResults, setQuizResults] = useState<any>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: quizzes, isLoading } = useQuery({
    queryKey: ["/api/quizzes"],
  });

  const updatePointsMutation = useMutation({
    mutationFn: async ({ points }: { points: number }) => {
      const response = await fetch(`/api/users/${user?.id}/points`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ points }),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
    },
  });

  const handleQuizComplete = (score: number, totalQuestions: number) => {
    const percentage = Math.round((score / totalQuestions) * 100);
    const pointsEarned = Math.round((selectedQuiz?.points || 75) * (percentage / 100));
    
    updatePointsMutation.mutate({ points: pointsEarned });
    
    setQuizResults({
      score: percentage,
      pointsEarned,
      quiz: selectedQuiz
    });
    setShowResults(true);
    
    toast({
      title: "Quiz Completed!",
      description: `You earned ${pointsEarned} eco-points with a ${percentage}% score!`,
    });
  };

  const handleBackToQuizzes = () => {
    setSelectedQuiz(null);
    setShowResults(false);
    setQuizResults(null);
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">Loading quizzes...</div>
      </div>
    );
  }

  if (selectedQuiz && !showResults) {
    return (
      <QuizInterface 
        quiz={selectedQuiz} 
        onComplete={handleQuizComplete}
        onBack={handleBackToQuizzes}
      />
    );
  }

  if (showResults) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="card-shadow">
          <CardContent className="p-8 text-center">
            <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-3xl">🎉</span>
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Quiz Completed!</h2>
            <p className="text-muted-foreground mb-6">
              Great job on completing the {quizResults?.quiz?.title}
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary" data-testid="quiz-score">
                  {quizResults?.score}%
                </div>
                <div className="text-sm text-muted-foreground">Score</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent" data-testid="quiz-points">
                  +{quizResults?.pointsEarned}
                </div>
                <div className="text-sm text-muted-foreground">Eco-points</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">
                  Level {user?.level || 1}
                </div>
                <div className="text-sm text-muted-foreground">Current Level</div>
              </div>
            </div>
            
            <div className="flex justify-center space-x-4">
              <Button
                onClick={handleBackToQuizzes}
                variant="secondary"
                data-testid="button-another-quiz"
              >
                Take Another Quiz
              </Button>
              <Button
                onClick={() => window.location.href = '/dashboard'}
                data-testid="button-view-dashboard"
              >
                View Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Environmental Quizzes</h1>
        <p className="text-muted-foreground mt-2">Test your environmental knowledge and earn eco-points</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {(quizzes as any[])?.map((quiz: any) => (
          <Card 
            key={quiz.id} 
            className="card-shadow hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => setSelectedQuiz(quiz)}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <span className="text-xl">{quiz.emoji}</span>
                </div>
                <span className="bg-blue-100 text-blue-700 text-xs font-medium px-2 py-1 rounded-full">
                  {quiz.questions?.length || 0} Questions
                </span>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2" data-testid={`quiz-title-${quiz.id}`}>
                {quiz.title}
              </h3>
              <p className="text-muted-foreground text-sm mb-4">{quiz.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-accent text-sm font-medium">🏆 {quiz.points} points</span>
                <Button 
                  className="text-sm"
                  data-testid={`quiz-start-${quiz.id}`}
                  onClick={(e) => {
                    e.preventDefault();
                    setSelectedQuiz(quiz);
                  }}
                >
                  Start Quiz →
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
