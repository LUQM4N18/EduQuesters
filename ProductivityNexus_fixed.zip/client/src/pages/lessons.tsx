import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Lessons() {
  const { data: lessons, isLoading } = useQuery({
    queryKey: ["/api/lessons"],
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">Loading lessons...</div>
      </div>
    );
  }

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Climate Science': 'from-blue-500 to-blue-600',
      'Waste Management': 'from-green-500 to-green-600',
      'Energy': 'from-yellow-500 to-orange-500',
      'Conservation': 'from-blue-500 to-green-500',
      'Biodiversity': 'from-purple-500 to-pink-500',
      'Sustainability': 'from-green-600 to-blue-600'
    };
    return colors[category] || 'from-gray-500 to-gray-600';
  };

  const getCategoryBadgeColor = (category: string) => {
    const colors: Record<string, string> = {
      'Climate Science': 'bg-primary/10 text-primary',
      'Waste Management': 'bg-green-100 text-green-700',
      'Energy': 'bg-yellow-100 text-yellow-700',
      'Conservation': 'bg-blue-100 text-blue-700',
      'Biodiversity': 'bg-purple-100 text-purple-700',
      'Sustainability': 'bg-green-100 text-green-700'
    };
    return colors[category] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Lessons</h1>
        <p className="text-muted-foreground mt-2">Learn about sustainability and environmental protection</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {(lessons as any[])?.map((lesson: any) => (
          <Card key={lesson.id} className="card-shadow overflow-hidden group hover:shadow-lg transition-shadow">
            <div className={`h-48 bg-gradient-to-br ${getCategoryColor(lesson.category)} p-6 flex items-center justify-center`}>
              <span className="text-6xl">{lesson.emoji}</span>
            </div>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${getCategoryBadgeColor(lesson.category)}`}>
                  {lesson.category}
                </span>
                <span className="text-xs text-muted-foreground">{lesson.duration} min</span>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2" data-testid={`lesson-title-${lesson.id}`}>
                {lesson.title}
              </h3>
              <p className="text-muted-foreground text-sm mb-4">{lesson.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-accent text-sm">🏆</span>
                  <span className="text-sm text-muted-foreground">{lesson.points} points</span>
                </div>
                {lesson.isLocked ? (
                  <Button
                    variant="secondary"
                    disabled
                    data-testid={`lesson-locked-${lesson.id}`}
                    className="text-sm cursor-not-allowed opacity-60"
                  >
                    🔒 Locked
                  </Button>
                ) : (
                  <Button
                    data-testid={`lesson-start-${lesson.id}`}
                    className="text-sm"
                  >
                    Start Lesson
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
