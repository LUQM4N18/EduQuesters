import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Profile() {
  const { user, logout } = useAuth();

  const { data: userBadges, isLoading: badgesLoading } = useQuery({
    queryKey: ["/api/users", user?.id, "badges"],
    enabled: !!user?.id,
  });

  const { data: userProgress } = useQuery({
    queryKey: ["/api/users", user?.id, "progress"],
    enabled: !!user?.id,
  });

  const { data: allBadges } = useQuery({
    queryKey: ["/api/badges"],
  });

  // Calculate progress stats
  const levelProgress = user ? ((user.ecoPoints || 0) % 1000) / 10 : 0;
  const lessonsCompleted = (userProgress as any[])?.filter((p: any) => p.lessonId && p.completed).length || 0;
  const quizzesCompleted = (userProgress as any[])?.filter((p: any) => p.quizId && p.completed).length || 0;
  const challengesCompleted = (userProgress as any[])?.filter((p: any) => p.challengeId && p.completed).length || 0;
  const pointsToNextLevel = 1000 - ((user?.ecoPoints || 0) % 1000);

  // Recent activity (mock data based on progress)
  const recentActivity = [
    { type: "quiz", title: "Recycling Quiz", time: "Today", color: "green" },
    { type: "lesson", title: "Water Conservation Lesson", time: "Yesterday", color: "blue" },
    { type: "challenge", title: "Plastic-Free Day Challenge", time: "3 days ago", color: "orange" },
  ];

  // Get earned badges with details
  const earnedBadges = (userBadges as any[])?.map((userBadge: any) => {
    const badge = (allBadges as any[])?.find((b: any) => b.id === userBadge.badgeId);
    return {
      ...userBadge,
      badge,
    };
  }) || [];

  // Sample locked badges
  const lockedBadges = [
    { name: "Planet Protector", emoji: "🔒", category: "achievement" },
    { name: "Carbon Neutral", emoji: "🔒", category: "achievement" },
  ];

  const allDisplayBadges = [
    ...earnedBadges,
    ...lockedBadges.map(badge => ({ badge, earnedAt: null }))
  ];

  const getBadgeBackgroundColor = (category: string, isEarned: boolean) => {
    if (!isEarned) return "bg-gray-100";
    
    const colors: Record<string, string> = {
      conservation: "bg-blue-100",
      waste: "bg-green-100",
      nature: "bg-yellow-100",
      knowledge: "bg-purple-100",
      transport: "bg-orange-100",
      energy: "bg-pink-100",
      achievement: "bg-red-100",
    };
    return colors[category] || "bg-teal-100";
  };

  const settingsOptions = [
    {
      title: "Edit Profile",
      description: "Update your personal information",
      icon: "✏️",
    },
    {
      title: "Notification Settings",
      description: "Manage challenge and achievement alerts", 
      icon: "🔔",
    },
    {
      title: "Privacy Settings",
      description: "Control your profile visibility",
      icon: "🔒",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Header */}
      <Card className="card-shadow mb-8">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8">
            <div className="text-center md:text-left">
              <div className="w-24 h-24 bg-primary/20 rounded-full flex items-center justify-center mx-auto md:mx-0 mb-4">
                <span className="text-4xl">👤</span>
              </div>
              <h1 className="text-2xl font-bold text-foreground" data-testid="profile-name">
                {user?.fullName}
              </h1>
              <p className="text-muted-foreground" data-testid="profile-school">
                {user?.school}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Joined {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'Recently'}
              </p>
            </div>
            
            <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary" data-testid="profile-level">
                  {user?.level || 1}
                </div>
                <div className="text-sm text-muted-foreground">Level</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-accent" data-testid="profile-points">
                  {user?.ecoPoints || 0}
                </div>
                <div className="text-sm text-muted-foreground">Eco-Points</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  #4
                </div>
                <div className="text-sm text-muted-foreground">Global Rank</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600" data-testid="profile-badges-count">
                  {earnedBadges.length}
                </div>
                <div className="text-sm text-muted-foreground">Badges</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Progress Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card className="card-shadow">
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">Level Progress</h2>
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-foreground">
                  Level {user?.level || 1} → Level {(user?.level || 1) + 1}
                </span>
                <span className="text-sm text-muted-foreground">{Math.round(levelProgress)}%</span>
              </div>
              <div className="w-full bg-secondary rounded-full h-3">
                <div 
                  className="bg-primary h-3 rounded-full progress-bar" 
                  style={{width: `${levelProgress}%`}}
                  data-testid="level-progress-bar"
                />
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {pointsToNextLevel} more points to level up
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Lessons Completed</span>
                <span className="text-sm font-medium text-foreground" data-testid="lessons-completed">
                  {lessonsCompleted}/15
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Quizzes Taken</span>
                <span className="text-sm font-medium text-foreground" data-testid="quizzes-completed">
                  {quizzesCompleted}/10
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Challenges Completed</span>
                <span className="text-sm font-medium text-foreground" data-testid="challenges-completed">
                  {challengesCompleted}/20
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-shadow">
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">Weekly Activity</h2>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className={`flex items-center justify-between p-3 bg-${activity.color}-50 rounded-lg`}>
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 ${
                      activity.color === 'green' ? 'bg-primary' : 
                      activity.color === 'blue' ? 'bg-blue-500' : 'bg-accent'
                    } rounded-full flex items-center justify-center`}>
                      <span className="text-white text-xs">
                        {activity.type === 'lesson' ? '📚' : activity.type === 'quiz' ? '✓' : '🎯'}
                      </span>
                    </div>
                    <span className="text-sm font-medium text-foreground" data-testid={`activity-${index}`}>
                      {activity.title}
                    </span>
                  </div>
                  <span className="text-xs text-muted-foreground">{activity.time}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Badges Collection */}
      <Card className="card-shadow mb-8">
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-foreground mb-6">Badge Collection</h2>
          {badgesLoading ? (
            <div className="text-center text-muted-foreground">Loading badges...</div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {allDisplayBadges.map((item: any, index: number) => {
                const isEarned = !!item.earnedAt;
                const badge = item.badge;
                return (
                  <div key={index} className="text-center group">
                    <div className={`w-16 h-16 ${getBadgeBackgroundColor(badge?.category, isEarned)} rounded-xl flex items-center justify-center mx-auto mb-2 group-hover:scale-105 transition-transform ${isEarned ? 'badge-glow' : 'opacity-50'}`}>
                      <span className="text-2xl">{isEarned ? badge?.emoji : '🔒'}</span>
                    </div>
                    <div className={`text-xs font-medium ${isEarned ? 'text-foreground' : 'text-muted-foreground'}`} data-testid={`badge-${index}`}>
                      {badge?.name}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {isEarned ? new Date(item.earnedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : 'Locked'}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Settings & Actions */}
      <Card className="card-shadow">
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-foreground mb-6">Account Settings</h2>
          <div className="space-y-4">
            {settingsOptions.map((option, index) => (
              <button
                key={index}
                className="w-full text-left p-4 hover:bg-secondary rounded-lg transition-colors"
                data-testid={`setting-${option.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-xl">{option.icon}</span>
                    <div>
                      <div className="font-medium text-foreground">{option.title}</div>
                      <div className="text-sm text-muted-foreground">{option.description}</div>
                    </div>
                  </div>
                  <span className="text-muted-foreground">→</span>
                </div>
              </button>
            ))}
            
            <button
              onClick={() => logout()}
              className="w-full text-left p-4 hover:bg-red-50 rounded-lg transition-colors"
              data-testid="button-sign-out"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-xl">🚪</span>
                  <div>
                    <div className="font-medium text-destructive">Sign Out</div>
                    <div className="text-sm text-muted-foreground">Log out of your account</div>
                  </div>
                </div>
                <span className="text-destructive">→</span>
              </div>
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
