import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import Navigation from "@/components/navigation";

// Pages
import Login from "@/pages/login";
import Signup from "@/pages/signup";
import Home from "@/pages/home";
import Dashboard from "@/pages/dashboard";
import Lessons from "@/pages/lessons";
import Quizzes from "@/pages/quizzes";
import Puzzles from "@/pages/puzzles";
import Challenges from "@/pages/challenges";
import Leaderboard from "@/pages/leaderboard";
import Profile from "@/pages/profile";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      {children}
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/" component={() => <Redirect to="/login" />} />
      
      <Route path="/home">
        <ProtectedRoute>
          <Home />
        </ProtectedRoute>
      </Route>
      
      <Route path="/dashboard">
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      </Route>
      
      <Route path="/lessons">
        <ProtectedRoute>
          <Lessons />
        </ProtectedRoute>
      </Route>
      
      <Route path="/quizzes">
        <ProtectedRoute>
          <Quizzes />
        </ProtectedRoute>
      </Route>
      
      <Route path="/puzzles">
        <ProtectedRoute>
          <Puzzles />
        </ProtectedRoute>
      </Route>
      
      <Route path="/challenges">
        <ProtectedRoute>
          <Challenges />
        </ProtectedRoute>
      </Route>
      
      <Route path="/leaderboard">
        <ProtectedRoute>
          <Leaderboard />
        </ProtectedRoute>
      </Route>
      
      <Route path="/profile">
        <ProtectedRoute>
          <Profile />
        </ProtectedRoute>
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
