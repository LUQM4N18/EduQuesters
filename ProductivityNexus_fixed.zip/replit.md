# EcoQuest - Gamified Environmental Education Platform

## Overview

EcoQuest is a full-stack gamified environmental education platform designed for schools and colleges. The application combines interactive learning with game mechanics to engage students in environmental awareness through lessons, quizzes, puzzles, and real-world challenges. Students earn eco-points, unlock badges, and compete on leaderboards while learning about sustainability, climate change, waste management, and conservation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and hot module replacement
- **Styling**: Tailwind CSS with a custom design system using CSS variables for theming
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible design
- **Routing**: Wouter for lightweight client-side routing without the complexity of React Router
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for type-safe form validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript for type safety across the entire stack
- **Session Management**: Express session middleware with cookie-based authentication
- **Password Security**: Bcrypt for hashing and salting user passwords
- **Development Setup**: Vite middleware integration for seamless full-stack development

### Database Architecture
- **ORM**: Drizzle ORM for type-safe database operations and schema management
- **Database**: PostgreSQL with Neon serverless hosting for scalability
- **Schema Design**: Comprehensive relational schema supporting users, lessons, quizzes, puzzles, challenges, badges, progress tracking, and eco-tips
- **Data Types**: JSON fields for flexible content storage (quiz questions, puzzle configurations)

### Authentication & Authorization
- **Strategy**: Session-based authentication using express-session
- **Security**: Password hashing with bcrypt, secure cookie configuration
- **Middleware**: Protected route middleware for API endpoints requiring authentication
- **User Management**: Full signup/login flow with user profile management

### Application Structure
- **Monorepo Layout**: Shared schema definitions between client and server in `/shared` directory
- **Client Structure**: Component-based architecture with pages, hooks, and utility functions
- **Server Structure**: Modular route handlers with centralized storage abstraction layer
- **Asset Management**: Vite-based asset bundling with proper path resolution

### Gamification System
- **Point System**: Eco-points awarded for completing activities (lessons: 50pts, quizzes: 75pts, challenges: variable)
- **Level Progression**: 1000 points per level with visual progress indicators
- **Badge System**: Achievement badges for various milestones and activities
- **Leaderboards**: Global and school-based ranking systems
- **Progress Tracking**: Comprehensive user progress monitoring across all activities

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL serverless database driver for scalable cloud database connectivity
- **drizzle-orm**: Modern TypeScript ORM for type-safe database operations and migrations
- **@tanstack/react-query**: Powerful data synchronization library for React applications
- **express-session**: Session middleware for Express with secure cookie management
- **bcrypt**: Industry-standard password hashing library for secure authentication

### UI & Styling Dependencies
- **@radix-ui/react-***: Comprehensive set of accessible, unstyled UI primitives (accordion, dialog, dropdown, etc.)
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **class-variance-authority**: Type-safe utility for creating component variants
- **clsx**: Utility for constructing className strings conditionally

### Development Dependencies
- **vite**: Next-generation frontend build tool with fast HMR and optimized builds
- **typescript**: Static type checking for enhanced developer experience and code reliability
- **wouter**: Minimalist routing library for React applications
- **react-hook-form**: Performant forms library with minimal re-renders

### Integration Services
- **Neon Database**: Serverless PostgreSQL database hosting with automatic scaling
- **Replit Infrastructure**: Development environment with cartographer and dev banner plugins for enhanced development experience

### Build & Deployment
- **esbuild**: Fast JavaScript bundler for server-side code compilation
- **PostCSS**: CSS processing tool with Tailwind CSS and Autoprefixer plugins
- **tsx**: TypeScript execution environment for development server